=== Cool Kids Network ===
Contributors: Your Name
Version: 1.0.0
Description: A custom WordPress plugin for managing user roles and authentication in Cool Kids Network.
